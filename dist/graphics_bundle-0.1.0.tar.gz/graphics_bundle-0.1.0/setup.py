# -*- coding: utf-8 -*-
from distutils.core import setup

modules = \
['graphics_bundle']
install_requires = \
['selenium>=3.141,<4.0']

entry_points = \
{'console_scripts': ['gbc = graphics_bundle:main']}

setup_kwargs = {
    'name': 'graphics-bundle',
    'version': '0.1.0',
    'description': 'Graphics bundle creator for Packt books on CDP',
    'long_description': None,
    'author': 'Rudolph Almeida',
    'author_email': 'rudolf1.almeida@gmail.com',
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
